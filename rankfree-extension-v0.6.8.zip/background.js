/**
 * RankFree 확장 — background service worker.
 * rankfree 서버와의 모든 통신(로그인/세션 확인/키워드 분석)을 담당한다.
 * content script 가 직접 cross-origin 호출을 하지 않도록 여기서 중계한다
 * (host_permissions 기반이라 CORS 제약이 없다).
 */

importScripts('shop-serp-policy.js', 'shop-serp-tab.js', 'shop-serp-pool.js');
const shopSerpTab = new ShopSerpTab();
const shopSerpPolicy = new ShopSerpPolicy();
const shopSerpPool = new ShopSerpPool({tabFactory: slot => slot ? new ShopSerpTab({slot}) : shopSerpTab, policyFactory: slot => slot ? new ShopSerpPolicy({storage:shopSerpPool.laneStorage(slot)}) : shopSerpPolicy});

const DEFAULT_API_BASE = 'https://rankfree.kr';


async function getStore() {
  const data = await chrome.storage.local.get(['rfToken', 'rfUser', 'rfApiBase', 'rfApiKey']);
  return {
    token: data.rfToken || null,
    user: data.rfUser || null,
    apiBase: (data.rfApiBase || DEFAULT_API_BASE).replace(/\/+$/, ''),
    apiKey: data.rfApiKey || null,
  };
}

async function apiFetch(path, { method = 'GET', body = null, token = null, apiBase } = {}) {
  const base = apiBase || (await getStore()).apiBase;
  const headers = { Accept: 'application/json' };
  if (body) headers['Content-Type'] = 'application/json';
  if (token) headers['Authorization'] = 'Bearer ' + token;

  let res;
  try {
    res = await fetch(base + path, {
      method,
      signal: AbortSignal.timeout(30000),
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    // 네트워크 오류·서버 미접속 → status 0 (토큰은 유지되어야 함)
    return { ok: false, status: 0, json: null, networkError: true };
  }

  let json = null;
  try {
    json = await res.json();
  } catch (e) {
    /* JSON 아님 */
  }
  return { ok: res.ok, status: res.status, json };
}

// 탭/창 닫기 — 사용자가 탭을 드래그 중이면 크롬이 "Tabs cannot be edited right now
// (user may be dragging a tab)" 로 프로미스를 '거부'한다. 콜백 없이 부르면 try/catch 로는
// 못 잡아 'Uncaught (in promise)' 로 샌다. 거부를 삼키고, 드래그가 끝나면 잠시 뒤 재시도해
// 수집 탭이 남지 않게 한다.
function removeTab(id, tries) {
  if (id == null) return;
  tries = tries == null ? 4 : tries;
  let p;
  try { p = chrome.tabs.remove(id); } catch (e) { return; }
  if (p && typeof p.catch === 'function') {
    p.catch((e) => {
      if (tries > 0 && /dragging|cannot be edited/i.test(String((e && e.message) || e))) {
        setTimeout(() => removeTab(id, tries - 1), 600);
      }
    });
  }
}

// 상품페이지 백그라운드 수집 완료 대기 — product.js 의 saveProductInfo 도착으로 해소된다.
const productInfoWaiters = new Map();

const handlers = {
  /** 로그인 → 토큰 저장 */
  async login({ email, password, apiBase }) {
    const base = (apiBase || DEFAULT_API_BASE).replace(/\/+$/, '');
    const { ok, status, json } = await apiFetch('/api/ext/login', {
      method: 'POST',
      body: { email, password, device_name: 'chrome-extension' },
      apiBase: base,
    });
    if (!ok || !json || !json.token) {
      return {
        ok: false,
        status,
        message:
          (json && (json.message || json.error)) ||
          (status === 0 ? '서버에 연결할 수 없습니다.' : '로그인에 실패했습니다. (' + status + ')'),
      };
    }
    await chrome.storage.local.set({
      rfToken: json.token,
      rfUser: json.user || null,
      rfApiBase: base,
    });
    return { ok: true, user: json.user || null };
  },

  /** 저장된 토큰이 유효한지 확인 */
  async session() {
    const { token, user, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/me', { token, apiBase });
    if (!ok) {
      // 토큰이 실제로 무효(401)일 때만 제거. 네트워크/서버 오류(0·5xx·429)엔
      // 토큰을 유지하고 캐시된 사용자로 로그인 상태를 보존(자꾸 풀리던 원인).
      if (status === 401) {
        await chrome.storage.local.remove(['rfToken', 'rfUser']);
        return { ok: true, loggedIn: false };
      }
      return { ok: true, loggedIn: Boolean(user), user: user || null, apiBase, transient: true };
    }
    const freshUser = (json && json.user) || user;
    await chrome.storage.local.set({ rfUser: freshUser });
    return { ok: true, loggedIn: true, user: freshUser, apiBase };
  },

  /** 로그아웃 */
  async logout() {
    const { token, apiBase } = await getStore();
    if (token) {
      try {
        await apiFetch('/api/ext/logout', { method: 'POST', token, apiBase });
      } catch (e) {
        /* 서버 실패해도 로컬 토큰은 지운다 */
      }
    }
    await chrome.storage.local.remove(['rfToken', 'rfUser']);
    return { ok: true };
  },

  /**
   * rankfree 키워드 분석.
   * API 키가 저장돼 있으면 공개 API v1 사용: 상세(성별·연령·트렌드) → 경량 순 폴백.
   * 키가 없으면 확장 로그인 토큰(ext) 경로 사용.
   */
  async keywordAnalysis({ keyword }) {
    const { token, apiBase, apiKey } = await getStore();
    const q = '?keyword=' + encodeURIComponent(keyword);

    if (apiKey) {
      for (const path of ['/api/v1/keyword/detail', '/api/v1/keyword']) {
        const { ok, status, json } = await apiFetch(path + q, { token: apiKey, apiBase });
        if (ok && json && json.data) {
          return { ok: true, data: json.data, source: 'api-key' };
        }
        if (status === 401) {
          return { ok: false, message: 'API 키가 유효하지 않습니다. 설정(⚙)에서 확인해 주세요.' };
        }
        if (status === 429) {
          return { ok: false, message: 'API 키 일일 한도를 초과했습니다.' };
        }
        // 403(scope 없음)·503(상세 소스 일시 장애) 등 → 다음 경로로 폴백
      }
    }

    if (!token) return { ok: false, loggedIn: false };

    // ext 토큰 경로 — 상세(성별·연령·12개월 트렌드) 우선, 실패 시 기본으로 폴백
    for (const path of ['/api/ext/keyword-analysis/detail', '/api/ext/keyword-analysis']) {
      const { ok, status, json } = await apiFetch(path + q, { token, apiBase });
      if (status === 401) {
        await chrome.storage.local.remove(['rfToken', 'rfUser']);
        return { ok: false, loggedIn: false };
      }
      if (ok && json && json.data) {
        return { ok: true, status, data: json.data, message: json.message, source: 'ext', share_token: json.share_token || null, apiBase };
      }
      // 503(상세 소스 일시 장애) 등 → 다음(기본) 경로로 폴백
    }
    return { ok: false, data: null, message: '키워드 분석 데이터를 조회하지 못했습니다.' };
  },

  /** '함께 많이 찾는'(SERP qra 모듈, badge 포함) — 서버가 SERP 크롤링. 확장 DOM scrape 대체 */
  async keywordTogether({ keyword }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, json } = await apiFetch('/api/ext/keyword-together?keyword=' + encodeURIComponent(keyword || ''), { token, apiBase });
    if (ok && json) return { ok: true, data: json.data || [] };
    return { ok: false, data: [] };
  },

  /** 쇼핑 상품명 SEO 분석 — 상품명 배열 → 제목 점수·공통단어·추천·노출 키워드 */
  async shoppingSeo({ keyword, products }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, json } = await apiFetch('/api/ext/shopping-seo', { method: 'POST', body: { keyword, products }, token, apiBase });
    if (ok && json) return { ok: true, data: json.data };
    return { ok: false, message: (json && json.message) || '상품명 SEO 분석에 실패했습니다.' };
  },

  /** 플레이스 리스트 순위(map.naver 배지) — 키워드 상위 오가닉 순위 목록(광고 제외·서울 고정 좌표) */
  async placeSerp({ keyword, cat, top }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const q = '?keyword=' + encodeURIComponent(keyword || '') + '&cat=' + encodeURIComponent(cat || '') + '&top=' + (top || 100);
    const { ok, status, json } = await apiFetch('/api/ext/place-serp' + q, { token, apiBase });
    if (status === 401) {
      await chrome.storage.local.remove(['rfToken', 'rfUser']);
      return { ok: false, loggedIn: false };
    }
    if (ok && json) {
      return { ok: true, blocked: !!json.blocked, total: json.total || 0, items: json.items || [] };
    }
    return { ok: false, message: (json && json.message) || '플레이스 순위를 조회하지 못했습니다.' };
  },

  /** 단일 매장 정밀 분석(매장분석) — 완전 N1/N2/N3 + D1~D10(D7/D9/D10 포함) */
  async placeDetail({ place_id, keyword, cat }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const q = '?place_id=' + encodeURIComponent(place_id || '') + '&keyword=' + encodeURIComponent(keyword || '') + '&cat=' + encodeURIComponent(cat || '');
    const { ok, status, json } = await apiFetch('/api/ext/place-detail' + q, { token, apiBase });
    if (status === 401) {
      await chrome.storage.local.remove(['rfToken', 'rfUser']);
      return { ok: false, loggedIn: false };
    }
    if (ok && json) {
      return { ok: true, detail: json.detail };
    }
    return { ok: false, message: (json && json.message) || '매장 상세 분석에 실패했습니다.' };
  },

  /** 시장 분석 결과 서버 저장 */
  async saveMarketAnalysis(payload) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/market-analyses', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return { ok, status, id: json && json.id, share_token: json && json.share_token, apiBase, message: json && json.message };
  },

  /** 저장된 분석 내역 목록 */
  async listMarketAnalyses({ limit } = {}) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/market-analyses?limit=' + (limit || 30), {
      token,
      apiBase,
    });
    return { ok, status, data: (json && json.data) || [] };
  },

  /** 저장된 분석 1건(스냅샷 포함) */
  async getMarketAnalysis({ id }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/market-analyses/' + encodeURIComponent(id), {
      token,
      apiBase,
    });
    return { ok, status, data: json && json.data };
  },

  /** 상품 분석(리뷰) 저장 */
  async saveProductAnalysis(payload) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/product-analyses', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return { ok, status, id: json && json.id, share_token: json && json.share_token, apiBase, message: json && json.message };
  },

  /** 상품정보(제목·업체명·가격·SEO태그) 저장 — 노출 키워드 분석 조합 재료(25) */
  async saveProductInfo(payload) {
    // 백그라운드 수집이 이 상품의 완료를 기다리고 있으면 payload 째로 알려준다(공개본엔 대기자가 없어 no-op)
    // (콘솔 페이지가 자기 서버에 직접 저장 — 확장 로그인이 prod 를 보고 있어도 로컬 분석이 동작)
    const notify = (r) => {
      const w = productInfoWaiters.get(String((payload && payload.channel_product_id) || ''));
      if (w) w(Object.assign({ payload }, r));
      return r;
    };
    const { token, apiBase } = await getStore();
    if (!token) return notify({ ok: false, loggedIn: false });
    const { ok, status, json } = await apiFetch('/api/ext/product-infos', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return notify({ ok, status, id: json && json.id, message: json && json.message });
  },

  async listProductAnalyses({ limit } = {}) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/product-analyses?limit=' + (limit || 30), {
      token,
      apiBase,
    });
    return { ok, status, data: (json && json.data) || [] };
  },

  async getProductAnalysis({ id }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/product-analyses/' + encodeURIComponent(id), {
      token,
      apiBase,
    });
    return { ok, status, data: json && json.data };
  },

  /** 플레이스 매장 분석 저장(정밀 분석 완료분) — 같은 매장×키워드는 서버에서 갱신 */
  async savePlaceAnalysis(payload) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/place-analyses', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return { ok, status, id: json && json.id, share_url: json && json.share_url, apiBase, message: json && json.message };
  },

  async listPlaceAnalyses({ limit } = {}) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/place-analyses?limit=' + (limit || 30), {
      token,
      apiBase,
    });
    return { ok, status, data: (json && json.data) || [] };
  },

  async getPlaceAnalysis({ id }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/place-analyses/' + encodeURIComponent(id), {
      token,
      apiBase,
    });
    return { ok, status, data: json && json.data };
  },

  async listSellerPower({ limit } = {}) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/seller-power?limit=' + (limit || 30), {
      token,
      apiBase,
    });
    return { ok, status, data: (json && json.data) || [], apiBase };
  },

  async getSellerPower({ id }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/seller-power/' + encodeURIComponent(id), {
      token,
      apiBase,
    });
    return { ok, status, data: json && json.data, apiBase };
  },

  /**
   * 네이버 쇼핑 페이지 HTML 가져오기 (셀러력 — 검색결과·경쟁 상품 상세).
   * content script 의 cross-origin 제약을 우회(host_permissions 기반, 브라우저 세션 쿠키 포함).
   */
  async spFetchHtml({ url }) {
    try {
      const res = await fetch(url, {
        credentials: 'include',
        headers: { Accept: 'text/html,application/json', 'Accept-Language': 'ko-KR,ko;q=0.9' },
      });
      const text = await res.text();
      return { ok: res.ok, status: res.status, text };
    } catch (e) {
      return { ok: false, status: 0, message: String((e && e.message) || e) };
    }
  },

  /**
   * 셀러력 경쟁 상품 상세 수집 — 봇 차단(429)으로 fetch 불가하니, 비활성 백그라운드 탭으로
   * 실제 렌더한 뒤 content script(수집 모드)가 __PRELOADED_STATE__를 추출해 보내면 탭을 닫는다.
   */
  async sellerCollectDetail({ url, shouldStop }) {
    return new Promise((resolve) => {
      let tabId = null;
      let done = false;
      const to = setTimeout(() => finish({ ok: false, timeout: true }), 20000);
      const stopTimer = setInterval(async () => {
        try {
          if (!done && shouldStop && await shouldStop()) finish({ ok: false, stopped: true, message: 'stopped' });
        } catch (e) { /* noop */ }
      }, 500);
      function finish(res) {
        if (done) return;
        done = true;
        clearTimeout(to);
        clearInterval(stopTimer);
        chrome.runtime.onMessage.removeListener(onMsg);
        removeTab(tabId);
        resolve(res);
      }
      function onMsg(msg, sender) {
        if (sender && sender.tab && sender.tab.id === tabId && msg && msg.type === '__spCollected') {
          finish({ ok: !!msg.ok, data: msg.data || null });
        }
      }
      chrome.runtime.onMessage.addListener(onMsg);
      try {
        chrome.tabs.create({ url: String(url).split('#')[0] + '#rfspcollect', active: false }, (tab) => {
          if (chrome.runtime.lastError || !tab) { finish({ ok: false, message: 'tab_create_failed' }); return; }
          tabId = tab.id;
        });
      } catch (e) {
        finish({ ok: false, message: String(e && e.message || e) });
      }
    });
  },

  async reviewCollectDetail({ url, title }, origin) {
    const originTabId = origin && origin.tab && origin.tab.id;
    const MAX_ATTEMPTS = 2;       // 최초 1회 + 재시도 1회
    const PER_ATTEMPT_MS = 150000; // 시도별 예산 — 백그라운드 탭은 타이머가 1초로 스로틀되어 여유 필요
    const collectUrl = String(url).split('#')[0] + '#rfreviewcollect';
    const jobBase = { url: String(url).split('#')[0], title: String(title || '') };
    // 잡 상태를 storage에 기록 — 사용자가 다른 페이지로 이동해도 진행·결과를 이어서 볼 수 있게 함
    const setJob = (patch) => { try { chrome.storage.local.set({ rfReviewJob: Object.assign({}, jobBase, patch) }); } catch (e) { /* noop */ } };
    setJob({ status: 'running', pct: 0, startedAt: Date.now() });
    return new Promise((resolve) => {
      let tabId = null;
      let done = false;
      let attempt = 0;
      let to = null;
      function armTimeout() { clearTimeout(to); to = setTimeout(onTimeout, PER_ATTEMPT_MS); }
      function finish(res) {
        if (done) return;
        done = true;
        clearTimeout(to);
        chrome.runtime.onMessage.removeListener(onMsg);
        removeTab(tabId);
        setJob({ status: 'done', ok: !!res.ok, html: res.html || '', name: res.name || '', message: res.message || '', id: res.id || null, share_token: res.share_token || null, finishedAt: Date.now() });
        resolve(res);
      }
      // 실패/타임아웃 시: 탭이 상품 메인으로 이탈해 해시가 유실됐을 수 있으므로,
      // reload 대신 collectUrl(#rfreviewcollect)로 재이동해 수집 모드를 재무장한다.
      // 포커스는 절대 가져오지 않는다(백그라운드 유지).
      function retryOrFail(failRes) {
        if (done) return;
        attempt++;
        if (attempt >= MAX_ATTEMPTS || tabId == null) { finish(failRes); return; }
        try {
          chrome.tabs.update(tabId, { url: collectUrl }, () => {
            if (chrome.runtime.lastError) { finish(failRes); return; }
          });
        } catch (e) { finish(failRes); return; }
        armTimeout();
      }
      function onTimeout() {
        retryOrFail({ ok: false, timeout: true, message: '분석 시간이 초과되었습니다. 리뷰가 많은 상품은 시간이 더 걸릴 수 있어요.' });
      }
      function onMsg(msg, snd) {
        if (!(snd && snd.tab && snd.tab.id === tabId && msg)) return;
        if (msg.type === '__reviewProgress') {
          setJob({ status: 'running', pct: msg.pct || 0, startedAt: Date.now() }); // 다른 페이지에서도 진행률 구독 가능
          if (originTabId != null) { try { chrome.tabs.sendMessage(originTabId, { type: '__reviewProgress', pct: msg.pct }); } catch (e) { /* noop */ } }
          return;
        }
        if (msg.type === '__reviewCollected') {
          if (msg.ok && msg.html) {
            finish({ ok: true, html: msg.html, name: msg.name || '', message: '', id: msg.id || null, share_token: msg.share_token || null });
          } else {
            retryOrFail({ ok: false, message: msg.message || '리뷰 분석에 실패했습니다.' });
          }
        }
      }
      chrome.runtime.onMessage.addListener(onMsg);
      try {
        // 백그라운드 탭 고정 — 사용자의 현재 페이지를 절대 바꾸지 않는다.
        // 렌더 없이도 리뷰 지연로딩이 발화하도록 injected-store.js가 visibility 스푸핑 +
        // 리뷰 섹션 한정 IntersectionObserver 합성 교차(setTimeout 기반, 배경 탭에서도 동작)를 건다.
        chrome.tabs.create({ url: collectUrl, active: false }, (tab) => {
          if (chrome.runtime.lastError || !tab) { finish({ ok: false, message: 'tab_create_failed' }); return; }
          tabId = tab.id;
          armTimeout();
        });
      } catch (e) {
        finish({ ok: false, message: String(e && e.message || e) });
      }
    });
  },

  /**
   * 쇼핑 순위체크(패널 UI) — 키워드 × 상품URL/업체명으로 지금 순위를 확인한다.
   *
   * 수집은 시장분석과 같은 수집기(collectShopping)로 하고, **순위 판정은 서버**가 한다 —
   * 워커(claim/result)와 같은 판정기를 써야 규칙(광고 제외 오가닉)이 두 곳으로 갈라지지 않는다.
   * 슬롯·큐를 만들지 않으므로 기록에 남지 않는 1회성 조회다.
   */
  async shopRankCheck({ keyword, target, count }) {
    const kw = String(keyword || '').trim();
    const tg = String(target || '').trim();
    if (!kw) return { ok: false, message: '키워드를 입력하세요.' };
    if (!tg) return { ok: false, message: '상품 URL 또는 업체명을 입력하세요.' };

    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false, message: '확장에 로그인해 주세요.' };

    // 대상 해석은 서버에 맡긴다(확장이 URL 파싱을 따로 갖지 않게) — 조기중단 힌트로만 쓴다.
    // 힌트가 있으면 대상을 찾는 즉시 수집을 멈춘다: 상위권 상품은 1페이지에서 끝나 훨씬 빠르고
    // 네이버 트래픽도 줄어든다. 실패해도 힌트 없이 끝까지 훑을 뿐 결과는 같다.
    const rs = await apiFetch('/api/ext/shop-rank/resolve', { method: 'POST', body: { target: tg }, token, apiBase });
    const hint = (rs && rs.ok && rs.json && rs.json.data) ? rs.json.data : null;

    const col = await handlers.collectShopping({
      keyword: kw,
      count: Number(count) || 400,
      match: hint ? { product_id: hint.product_id || '', mall_name: hint.mall_name || '' } : undefined,
    });
    if (!col || !col.ok || !Array.isArray(col.products) || !col.products.length) {
      return {
        ok: false,
        blocked: !!(col && col.blocked),
        message: (col && col.message) || '상품 목록을 가져오지 못했습니다.',
      };
    }

    const { ok, json } = await apiFetch('/api/ext/shop-rank/check', {
      method: 'POST',
      body: { keyword: kw, target: tg, products: col.products, total: col.total || 0 },
      token,
      apiBase,
    });
    if (!ok || !json || !json.ok) {
      return { ok: false, message: (json && json.message) || '순위 판정에 실패했습니다.' };
    }

    return { ok: true, data: json.data, scanned: col.products.length, total: col.total || 0 };
  },

  async collectShopping({ keyword, count, match }) {
    return new Promise((resolve) => {
      let tabId = null;
      let done = false;
      let loaded = false;    // tabs.onUpdated status:complete — 페이지가 실제로 떴다
      let started = false;   // content script(document_idle) 시작 신호 — 수집 스크립트가 돈다
      let stall = null;      // '떴는데 수집 스크립트가 안 붙음'(에러 페이지 등) 판정용

      // 상품 5페이지(약 20초) + 가격비교 카탈로그 확장(예산 20초) + 여유.
      // 순위체크는 1000위(13페이지)까지 뒤지므로 요청 개수에 비례해 늘린다 — 고정 75초면 깊은 스캔이 항상 타임아웃난다.
      const budgetMs = Math.min(300000, 75000 + Math.max(0, (Number(count) || 80) - 400) * 90);
      const to = setTimeout(() => finish({ ok: false, timeout: true, message: '상품 수집 시간이 초과되었습니다.' }), budgetMs);

      // '안 열림 = 차단' 판정. 예전엔 시작 신호를 12초 안 받으면 차단으로 봤으나, 동시 수집(백그라운드 탭 N개)에서는
      //   크롬이 background 탭의 document_idle content script 주입을 뒤로 미뤄, 페이지는 3~4초에 떠도 시작 신호가
      //   12초를 넘겨 도착 → 멀쩡한 페이지를 차단으로 오판했다(실측: 동시 4에서 다발, 로딩은 12초도 안 걸림).
      //   → 열림 판정을 시작 신호가 아니라 '실제 페이지 로드 완료(tabs.onUpdated status:complete)'로 바꾼다.
      //     이 신호는 content script 주입 스케줄링과 무관하게 네트워크/렌더 완료 시점에 온다.
      //   alive: complete·시작신호 둘 다 30초 없으면 진짜 미로딩(연결 실패·차단)으로 보고 차단 처리(백오프).
      //     동시수를 상한(10)까지 올리거나 회선이 느리면 complete 가 20초대에 오기도 해 30초로 여유를 둔다.
      const alive = setTimeout(() => {
        if (!loaded && !started) finish({ ok: false, message: '페이지가 열리지 않았습니다 — 차단(429)으로 보입니다.' });
      }, 30000);
      const clearBlockTimers = () => { clearTimeout(alive); if (stall) { clearTimeout(stall); stall = null; } };
      const isGateUrl = (u) => !!u && /^https:\/\/(nid\.naver\.com|captcha\.naver\.com|ncpt\.naver\.com)\//i.test(u);

      // 페이지가 실제로 떴다(complete) — '안 열림' 판정 해제. 단, 떴는데도 수집 스크립트가 15초 안 붙으면
      //   대개 네이버 429 에러 페이지다("HTTP ERROR 429" — 크롬 에러 페이지라 status:complete 는 뜨지만
      //   content script 가 주입되지 않아 시작 신호가 영영 안 온다). → 차단으로 보고 백오프시킨다(메시지에
      //   429·차단 토큰을 넣어 looksBlocked 매칭). 정상 페이지는 complete 후 시작 신호가 수 초 내 오므로 15초면
      //   오탐이 없다(원 버그는 create→complete 지연이 컸던 것이지 complete→started 간격은 짧다).
      const markLoaded = () => {
        if (loaded || started) return;
        loaded = true;
        clearTimeout(alive);
        if (!stall) stall = setTimeout(() => {
          if (!started) finish({ ok: false, message: '페이지는 떴으나 수집 스크립트 미응답 — 429 차단으로 보입니다.' });
        }, 15000);
      };

      // 탭 상태 감시 — 캡차/로그인 리다이렉트(진짜 차단)는 즉시, 로드 완료는 '열림'으로 본다.
      const onUpd = (id, info) => {
        if (!tabId || id !== tabId || !info) return;
        if (isGateUrl(info.url || '')) {
          // 네이버가 보안(캡차/로그인) 게이트로 돌렸다 — 확실한 차단. 타이머 안 기다리고 즉시 판정.
          finish({ ok: false, message: '네이버 보안(캡차) 감지 — 차단으로 보입니다.' });
          return;
        }
        if (info.status === 'complete') markLoaded();
      };

      function finish(res) {
        if (done) return;
        done = true;
        clearTimeout(to);
        clearBlockTimers();
        chrome.runtime.onMessage.removeListener(onMsg);
        try { chrome.tabs.onUpdated.removeListener(onUpd); } catch (e) { /* noop */ }
        removeTab(tabId);
        resolve(res);
      }
      function onMsg(msg, sender) {
        if (!sender || !sender.tab || sender.tab.id !== tabId || !msg) return;
        // 수집 스크립트가 떴다 — 페이지는 정상이니 차단 판정 타이머를 모두 끈다(수집 자체는 계속 기다린다)
        if (msg.type === '__shoppingCollectStarted') { started = true; clearBlockTimers(); return; }
        // 페이지별 진행 — 몇 페이지에서 몇 개를 받았고 왜 멈췄는지가 여기서만 보인다
        if (msg.type === '__shoppingCollectProgress') {
          console.log('[RankFree]   ' + msg.page + '페이지: +' + msg.got
            + ' (누적 ' + msg.organic + '/' + msg.target + ')' + (msg.note ? ' — ' + msg.note : ''));
          return;
        }
        if (msg.type === '__shoppingCollected') {
          finish({
            ok: !!msg.ok, products: msg.products || [], total: msg.total || 0,
            relatedTags: msg.relatedTags || [], message: msg.message || '',
            blocked: !!msg.blocked,   // 418/429 — 워커가 이걸 보고 즉시 쉰다
          });
        }
      }
      chrome.runtime.onMessage.addListener(onMsg);
      try { chrome.tabs.onUpdated.addListener(onUpd); } catch (e) { /* noop */ }
      try {
        // 조기 중단 힌트(pid·mall)를 함께 넘긴다 — 대상을 찾으면 페이지 수집을 멈춰 차단을 피한다
        const hint = match ? ('&pid=' + encodeURIComponent(match.product_id || '') + '&mall=' + encodeURIComponent(match.mall_name || '')) : '';
        const url = 'https://search.shopping.naver.com/search/all?query=' + encodeURIComponent(String(keyword || '')) + '#rfcollect=' + (Number(count) || 80) + hint;
        chrome.tabs.create({ url, active: false }, (tab) => {
          if (chrome.runtime.lastError || !tab) { finish({ ok: false, message: 'tab_create_failed' }); return; }
          tabId = tab.id;
          if (done) { removeTab(tab.id); return; }   // 콜백 전에 이미 끝났으면(타이머 등) 고아 탭 정리
          // ★ 콜백 이전에 도착해 !tabId 가드로 놓쳤을 수 있는 캡차 리다이렉트/complete 를 1회 보정(경합 하드닝)
          try {
            chrome.tabs.get(tab.id, (t) => {
              if (chrome.runtime.lastError || !t || done) return;
              if (isGateUrl(t.url || t.pendingUrl || '')) { finish({ ok: false, message: '네이버 보안(캡차) 감지 — 차단으로 보입니다.' }); return; }
              if (t.status === 'complete') markLoaded();
            });
          } catch (e) { /* noop */ }
        });
      } catch (e) {
        finish({ ok: false, message: String(e && e.message || e) });
      }
    });
  },

  /** 셀러력 경쟁 상품 목록 — 서버가 shop.json으로 검색(검색 API 봇 차단 우회). */
  async sellerCompetitors({ keyword }) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/seller-power/competitors?keyword=' + encodeURIComponent(keyword), { token, apiBase });
    return { ok, status, products: (json && json.products) || [] };
  },

  /** 셀러력 분석 결과 서버 저장(서버가 계산해 결과 반환). */
  async saveSellerPower(payload) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/seller-power', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return { ok, status, id: json && json.id, shareToken: json && json.share_token, apiBase, result: json && json.result, message: json && json.message };
  },

  /** 톡톡/스토어 연락 식별자 수집 저장(마케팅 리드 · 조회는 슈퍼어드민). */
  async harvestTalk(payload) {
    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false };
    const { ok, status, json } = await apiFetch('/api/ext/talk-contacts', {
      method: 'POST',
      body: payload,
      token,
      apiBase,
    });
    return { ok, status, saved: json && json.saved };
  },

  /** 확장 설정 조회 (API 키 등) */
  async getSettings() {
    const { apiKey, apiBase } = await getStore();
    return { ok: true, apiKey: apiKey || '', apiBase };
  },

  /** 확장 설정 저장 — 빈 값이면 키 제거 */
  async saveSettings({ apiKey }) {
    const value = String(apiKey || '').trim();
    if (value) {
      await chrome.storage.local.set({ rfApiKey: value });
    } else {
      await chrome.storage.local.remove('rfApiKey');
    }
    return { ok: true, hasKey: Boolean(value) };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // The active collection reader answers this request for its trusted tab.
  if (msg?.type === '__rfSerpTarget') return false;
  const handler = handlers[msg && msg.type];
  if (!handler) {
    sendResponse({ ok: false, message: 'unknown message: ' + (msg && msg.type) });
    return false;
  }
  handler(msg.payload || {}, sender)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, message: String((e && e.message) || e) }));
  return true; // async 응답
});

/* ──────────────────────────────────────────────────────────────────────────
 * 순위 워커 · 대량 수집 · SERP 대행
 *
 * 한때 웹스토어 심사를 의식해 별도 빌드로 분리했다가, 쇼핑 주문을 넣는 누구나
 * 상품정보 수집을 쓸 수 있어야 해서 다시 하나로 합쳤다(2026-08-10).
 * 심사 관점의 리스크와 판단 근거는 .claude/30_EXTENSION_PUBLIC_INTERNAL_SPLIT.md 참조.
 *
 * ⚠️ 이 블록은 `const handlers`(위쪽) 이후여야 한다 — TDZ.
 * ────────────────────────────────────────────────────────────────────────── */

// ── 대량 쇼핑 수집 워치독 ─────────────────────────────────────────────────────
// MV3 서비스워커는 유휴 시 크롬이 종료시켜 bulkShopStart 의 장기 루프가 통째로 죽는다(실측: 돌려두면
// 수집하다가 꺼짐). 예전엔 재기동 시 running 플래그만 내리고 자동 재개가 없어 그대로 멈췄다.
// → desired 세션인 동안 chrome.alarms 로 SW 를 주기적으로 깨워, 루프가 죽었으면(이 SW 에 살아있는
//    루프가 없으면) 원본 파라미터로 재개한다. 알람은 SW 종료·브라우저 재시작을 넘어 살아남는다.
const BULK_WATCHDOG_ALARM = 'rfBulkWatchdog';
let bulkLoopActive = false;   // 이 SW 인스턴스에 살아있는 수집 루프가 있는지(동기 플래그 — 중복 시작 방지)

// 워치독/재시작 훅이 호출 — 계속 수집을 원하는(desired) 세션인데 루프가 죽었으면 재개한다.
async function resumeBulkIfNeeded(reason, ignoreHeartbeat) {
  try {
    const b = (await chrome.storage.local.get(['rfBulk'])).rfBulk;
    if (!b || !b.desired || b.stop) {                       // 원하지 않거나 중단됨 — 알람 정리
      try { await chrome.alarms.clear(BULK_WATCHDOG_ALARM); } catch (e) { /* noop */ }
      return;
    }
    if (bulkLoopActive) return;                              // 이 SW 에 루프가 살아있다 — 재개 불필요
    // heartbeat 가 신선하면 방금까지 살아있던 것 — 다음 알람에서 재판정(SW 재시작 훅은 무시하고 즉시 재개).
    const stale = ignoreHeartbeat || !b.heartbeat || (Date.now() - b.heartbeat) > 45000;
    if (b.running && !stale) return;
    const p = b.params || {};
    await handlers.bulkShopStart({ limit: p.limit, delayMs: p.delayMs, concurrency: p.concurrency, force: true });
  } catch (e) { /* noop */ }
}

// ── 쇼핑 유입키워드 상품정보 자동 수집(2026-07-29) ────────────────────────────────
// 서버는 상품페이지를 직접 못 읽는다(429 + 스토어 SPA). 관리자 화면에서는 사람이 분석 화면을 열면
// 확장이 채워주지만, 외부 API 로 만든 분석은 그 화면을 여는 사람이 없다.
// → 요청자가 확장만 켜 두면 이 폴러가 자기 분석의 상품정보를 화면 없이 채우고, 서버가 조합 재생성 ·
//   순위확인까지 이어서 돌린다. shop_keyword 권한이 없는 계정은 서버가 403 → 오래 쉰다(부담 0).
const SKW_QUEUE_ALARM = 'rfShopKwProductQueue';
let skwQueueActive = false;

// ── 쇼핑 순위체크 워커(2026-08-03) ─────────────────────────────────────────
// 네이버가 openapi shop.json 을 종료해(공지 32564) 서버가 순위를 직접 못 구한다. 서버 크롤링도 막힌다
// (쇼핑검색 API 는 nCaptcha 토큰 없으면 418, 구 search/all 은 로그인·캡차).
// → 확장이 켜진 PC 가 **시장분석 수집기 그대로**(collectShopping) 목록을 가져와 서버로 보내고,
//   매칭·순위 계산은 서버가 한다. 여러 대가 켜져 있으면 서버 claim 이 원자적이라 자연히 분산된다.
const SHOP_RANK_ALARM = 'rfShopRankWorker';
let shopRankActive = false;

/** 이 설치를 식별하는 워커 ID — 누가 잡았는지 추적하고, 남의 결과로 덮어쓰지 않기 위해 필요하다. */
async function getWorkerId() {
  const s = await chrome.storage.local.get(['rfWorkerId']);
  if (s.rfWorkerId) return s.rfWorkerId;
  const id = 'w-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
  await chrome.storage.local.set({ rfWorkerId: id });
  return id;
}

async function drainShopRankQueue(why) {
  // 왜 안 도는지 눈에 보여야 한다 — 조용히 return 하면 "반응 없음"으로만 보인다.
  const log = (m, ...a) => console.log('[RankFree] 순위워커(' + (why || '?') + '): ' + m, ...a);

  if (shopRankActive) return log('이미 실행 중 — 건너뜀');
  if (Date.now() - lastScreenSerpAt < 60000) return log('화면 수집이 방금 돌아 양보');
  // 순위체크는 **서버가 시키는 일**이라 사용자 로그인·별도 설정이 필요 없다. 확장이 깔려 있으면 그냥 돈다.
  const { apiBase } = await getStore();
  const s = await chrome.storage.local.get(['rfShopRankSkipUntil']);
  if (Date.now() < (s.rfShopRankSkipUntil || 0)) {
    return log('백오프 중(캡차/권한) — 해제 ' + new Date(s.rfShopRankSkipUntil).toLocaleTimeString());
  }
  log('큐 조회 시작 →', apiBase);

  shopRankActive = true;
  const workerId = await getWorkerId();
  const startedAt = Date.now();
  try {
    // 알람 주기(1분) 직전까지만 돈다 — 끝나는 즉시 다음 알람이 이어받아 '듣는 사람이 없는' 구간이 없다.
    // 한 사이클에 처리할 작업 수 상한 — 큐가 20건 쌓였다고 연속으로 다 훑으면 네이버가 IP 를 막는다(실측).
    let doneThisCycle = 0;

    while (Date.now() - startedAt < 55000 && doneThisCycle < 3) {
      // wait: 서버가 줄 게 없으면 잠깐 붙잡고 기다린다(롱폴링) — 알람(1분)만 믿으면 픽업이 늦다.
      // 대기 중인 fetch 가 서비스워커도 깨워 두므로, 확장 화면을 열어두지 않아도 계속 돈다.
      const q = await apiFetch('/api/ext/shop-rank/claim', {
        method: 'POST', body: { worker_id: workerId, limit: 2, wait: 25 }, apiBase,
      });
      if (q.status === 403) {                                 // 권한 없음 — 오래 쉰다
        await chrome.storage.local.set({ rfShopRankSkipUntil: Date.now() + 6 * 3600 * 1000 });
        return;
      }
      if (!q.ok || !q.json || !q.json.data) {
        // 404 면 서버 주소가 워커 API 없는 곳(미배포 서버), 401 이면 토큰 만료
        console.warn('[RankFree] 순위워커 claim 실패:', q.status, apiBase);

        return;                                               // 일시 오류 — 다음 알람에 재시도
      }
      const items = q.json.data.items || [];
      // 빈 큐라고 빠져나오면 다음 알람(1분)까지 아무도 안 듣는 구간이 생긴다 —
      // 사용자가 그 사이 순위체크를 누르면 그만큼 늦는다. 예산 안에서는 계속 대기한다(롱폴링).
      if (!items.length) continue;
      log('작업 ' + items.length + '건 수령:', items.map((i) => i.keyword).join(', '));

      for (const it of items) {
        if (Date.now() - lastScreenSerpAt < 60000) return;    // 도중에 화면이 시작되면 즉시 양보

        let res = null;
        try {
          res = await handlers.collectShopping({ keyword: it.keyword, count: it.count || 80, match: it.match });
        } catch (e) {
          res = { ok: false, message: String((e && e.message) || e) };
        }

        if (!res || res.ok === false || !Array.isArray(res.products) || !res.products.length) {
          const captcha = !!(res && (res.captcha || res.blocked));
          log('❌ 「' + it.keyword + '」 수집 실패' + (captcha ? '(보안문자)' : '') + ' — ' + ((res && res.message) || '이유 없음'));
          await apiFetch('/api/ext/shop-rank/' + it.job_id + '/fail', {
            method: 'POST', apiBase,
            body: { worker_id: workerId, error: captcha ? 'captcha' : ((res && res.message) || 'empty').slice(0, 60) },
          });
          if (captcha) {
            // 이 PC 는 한동안 못 쓴다 — 작업은 서버가 다시 큐에 둬서 다른 워커가 집어간다.
            // 보안문자를 한 번 맞으면 곧바로 재시도할수록 더 깊이 막힌다(실측: 사용자가 캡차를 대량으로 풀어야 했다).
            await chrome.storage.local.set({ rfShopRankSkipUntil: Date.now() + 2 * 3600 * 1000 });
            try { chrome.action.setBadgeText({ text: '!' }); } catch (e) { /* noop */ }
            return;
          }
          continue;
        }

        log('「' + it.keyword + '」 수집 완료 — ' + res.products.length + '개 (목표 ' + it.count + ')');

        /*
         * 🔴 상품을 좀 받았어도 도중에 418 을 맞았으면 그 자리에서 멈춘다.
         * 안 그러면 "부족 → 다음 작업 → 또 418" 로 큐 전체를 훑으며 IP 가 통째로 막힌다(실측).
         */
        if (res.blocked) {
          log('⛔ 네이버가 요청을 거부했습니다(418/429) — 수집을 중단하고 2시간 쉽니다');
          await apiFetch('/api/ext/shop-rank/' + it.job_id + '/fail', {
            method: 'POST', apiBase, body: { worker_id: workerId, error: 'blocked_418' },
          });
          await chrome.storage.local.set({ rfShopRankSkipUntil: Date.now() + 2 * 3600 * 1000 });
          try { chrome.action.setBadgeText({ text: '!' }); } catch (e) { /* noop */ }

          return;
        }

        const r = await apiFetch('/api/ext/shop-rank/' + it.job_id + '/result', {
          method: 'POST', apiBase,
          body: { worker_id: workerId, products: res.products, total: res.total || 0 },
        });
        if (!r.ok) await reportShopClientEvent(d.analysis_id, it.keyword, 'save', 'HTTP ' + r.status);
        if (r.status === 401 || r.status === 403) return;

        // 결과를 눈으로 확인할 수 있게 — 순위가 몇 위로 잡혔는지, 부족해서 되돌려졌는지
        const d = (r.json && r.json.data) || {};
        if (d.partial) {
          log('⚠ 「' + it.keyword + '」 수집 부족(' + d.scanned + '/' + d.wanted + ') — 미노출로 기록하지 않고 재시도');
        } else if (d.found) {
          log('✅ 「' + it.keyword + '」 ' + d.rank + '위' + (d.ad ? ' (광고 노출도 있음)' : ''));
        } else {
          log('「' + it.keyword + '」 ' + it.count + '위 안에서 미노출');
        }

        doneThisCycle++;
        await new Promise((x) => setTimeout(x, 3000 + Math.random() * 2000));   // 페이싱 — 연속 수집은 캡차를 부른다
      }
    }
  } catch (e) { /* noop */ } finally {
    shopRankActive = false;
  }
}

async function drainShopKeywordProductQueue() {
  if (skwQueueActive) return;                       // 이 SW 에서 이미 수집 중
  const { token, apiBase } = await getStore();
  if (!token) return;                               // 미로그인
  const skipUntil = (await chrome.storage.local.get(['rfSkwSkipUntil'])).rfSkwSkipUntil || 0;
  if (Date.now() < skipUntil) return;               // 권한 없음 등으로 백오프 중

  skwQueueActive = true;
  try {
    const q = await apiFetch('/api/ext/shop-keyword/product-queue?limit=3', { token, apiBase });
    if (q.status === 403) {                         // 권한 없는 계정 — 6시간 쉰다
      await chrome.storage.local.set({ rfSkwSkipUntil: Date.now() + 6 * 3600 * 1000 });
      return;
    }
    if (!q.ok || !q.json || !q.json.data) return;   // 네트워크·일시 오류 — 다음 알람에 재시도
    for (const it of (q.json.data.items || [])) {
      if (!it || !it.product_url) continue;
      const pi = await handlers.collectProductPage({ url: it.product_url });
      // 실패(로그인 게이트·타임아웃)는 남겨 두면 다음 주기에 다시 시도된다
      if (!pi || !pi.ok || !pi.info) continue;
      await apiFetch('/api/ext/shop-keyword/' + it.analysis_id + '/product-info', {
        method: 'POST', body: { info: pi.info }, token, apiBase,
      });
      await new Promise((r) => setTimeout(r, 1500));   // 연속 탭 열기 간격
    }
  } catch (e) { /* noop */ } finally {
    skwQueueActive = false;
  }
}

// 순위 확인도 확장이 이어받는다(2026-07-29) — 서버는 API 분석의 순위를 자동으로 돌리지 않는다.
// 상품정보가 채워져야 조합이 생기므로 상품정보 큐 다음에 실행한다.
let skwCheckActive = false;
let skwCheckHeartbeat = 0;
let lastScreenSerpAt = 0;   // 관리자 화면 루프가 m.search 를 쓴 시각 — 같은 IP 이중 크롤 방지용

async function reportShopClientEvent(analysisId, keyword, stage, message, kind = 'client_error') {
  try {
    const {token, apiBase} = await getStore();
    if (token && analysisId) await apiFetch('/api/ext/shop-keyword/' + analysisId + '/collector-event', {
      method: 'POST', token, apiBase, body: {kind, keyword: String(keyword || '').slice(0,300), stage, message: String(message).slice(0,1000)},
    });
  } catch (_) {}
}
async function watchShopKeywordQueue() {
  if (skwCheckActive && Date.now() - skwCheckHeartbeat > 120000) {
    // Reload terminates the old lane and its callbacks before a new worker claims a lease.
    const current = globalThis.rfSerpCurrent || {};
    await reportShopClientEvent(current.analysisId, current.keyword, 'watchdog', 'worker promise stalled >120s', 'watchdog_restart');
    chrome.runtime.reload();
    return;
  }
  await drainShopKeywordCheckQueue(true);
}

async function drainShopKeywordCheckQueue(watchdog = false) {
  if (skwCheckActive) return;
  if (!watchdog && Date.now() - lastScreenSerpAt < 60000) return;      // 화면이 돌고 있으면 양보
  const { token, apiBase } = await getStore();
  if (!token) return;
  const s = await chrome.storage.local.get(['rfSkwCheckSkipUntil', 'rfSkwCheckSkipReason', 'rfSerpPolicy']);
  const until = s.rfSerpPolicy && s.rfSerpPolicy.until;
  if (s.rfSkwCheckSkipReason !== 'permission' && s.rfSkwCheckSkipUntil > Date.now() + 180000
      && (s.rfSkwCheckSkipReason === 'naver' || (until && Math.abs(s.rfSkwCheckSkipUntil - until) <= 5000))) {
    s.rfSkwCheckSkipUntil = Date.now() + 180000;
    await chrome.storage.local.set({ rfSkwCheckSkipUntil: s.rfSkwCheckSkipUntil, rfSkwCheckSkipReason: 'naver',
      rfSerpPolicy: { ...s.rfSerpPolicy, until: s.rfSkwCheckSkipUntil } });
    chrome.alarms.create('rf-skw-check-retry', { when: s.rfSkwCheckSkipUntil });
  }
  if (Date.now() < (s.rfSkwCheckSkipUntil || 0)) return;  // 권한 없음·차단 백오프 중

  if (skwCheckActive) return; // Another alarm may have claimed the lane while storage was loading.
  const failedItems = new Set();
  const runner = crypto.randomUUID();
  let parallelTabs = 4;
  skwCheckActive = true;
  skwCheckHeartbeat = Date.now();
  try {
    while (true) { // 작업이 있는 동안 알람 경계 없이 계속 처리한다
      const q = await apiFetch('/api/ext/shop-keyword/check-queue?limit=' + parallelTabs + (watchdog ? '&watchdog=1' : '') + '&runner=' + runner + [...failedItems].map(id => '&exclude[]=' + id).join(''), { token, apiBase });
      if (q.status === 403) {                              // 권한 없는 계정 — 오래 쉰다
        await chrome.storage.local.set({ rfSkwCheckSkipUntil: Date.now() + 6 * 3600 * 1000, rfSkwCheckSkipReason: 'permission' });
        return;
      }
      if (!q.ok || !q.json || !q.json.data) return;        // 네트워크·일시 오류 — 다음 알람에 재시도
      const d = q.json.data;
      const items = d.items || [];
      if (watchdog && items.length) {
        await reportShopClientEvent(d.analysis_id, items[0].keyword, 'takeover', 'no saves for 120s; queue resumed', 'watchdog_restart');
        lastScreenSerpAt = 0; watchdog = false;
      }
      if (!items.length) return;                           // 확인할 조합 없음
      let batchStopped = false;
      const processItem = async it => {
        if (batchStopped) return;
        if (Date.now() - lastScreenSerpAt < 60000) return; // 도중에 화면이 시작되면 즉시 양보
        let res;
        do {
          res = await handlers.fetchShopSerp({ keyword: it.keyword, target: d.target, collection_mode: d.collection_mode, collectorIp: d.collector_ip, interval_ms: d.interval_ms, interval_revision: d.interval_revision, analysisId: d.analysis_id, parallel_tabs: d.parallel_tabs, tab_open_interval_ms: d.tab_open_interval_ms });
          if (res?.parallel_reduced) parallelTabs = 1;
          skwCheckHeartbeat = Date.now();
          if (!(res && (res.cooldown || res.captcha || res.status === 403 || res.status === 429))) break;
          await sleep(1500);
          if (Date.now() - lastScreenSerpAt < 60000) return;
        } while (true);
        if (!res || res.ok === false) {
          await reportShopClientEvent(d.analysis_id, it.keyword, 'read', res?.message || 'empty result');
          failedItems.add(it.item_id);
          globalThis.rfSerpCurrent = { keyword: it.keyword, screen: '못 읽음' };
          return;
        }
        const r = await apiFetch('/api/ext/shop-keyword/' + d.analysis_id + '/check-html', {
          method: 'POST', body: { item_id: it.item_id, html: res.html || '', result_source: res.result_source, runner, claim_token: it.claim_token }, token, apiBase,
        });
        if (!r.ok) await reportShopClientEvent(d.analysis_id, it.keyword, 'save', 'HTTP ' + r.status);
        if (r.status === 401 || r.status === 403) return;
        if (r.json && r.json.status === 'target_reached') batchStopped = true;
        // 공용 ShopSerpPolicy가 저장된 기본 간격과 실제 차단 후 대기를 적용한다.
      };
      // Tab opening may legitimately take 3 * 60s. Renew reservations while those jobs wait.
      const heartbeat = typeof setInterval === 'function' ? setInterval(() => {
        apiFetch('/api/ext/shop-keyword/check-queue?policy_only=1&runner=' + runner, {token,apiBase}).catch(() => {});
      }, 30000) : null;
      try {
        if (Number(d.parallel_tabs) > 1) await Promise.all(items.map(processItem));
        else for (const it of items) { await processItem(it); if (batchStopped) break; }
      } finally { if (heartbeat !== null) clearInterval(heartbeat); }

    }
  } catch (e) {
    const current = globalThis.rfSerpCurrent || {};
    await reportShopClientEvent(current.analysisId, current.keyword, 'queue', e.message);
  } finally {
    skwCheckActive = false;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ── 쇼핑 노출 키워드(25) 화면단 순위체크 ──────────────────────────────────────
// m.search HTML(수백 KB~MB)에서 가격비교 _INITIAL_STATE 가 든 <script> 조각만 추린다.
// 서버 파서(NaverShopExposureService)는 _INITIAL_STATE 마커로 찾으므로 조각만 보내도 되고 전송량이 크게 준다.
function pickInitialStateScripts(html) {
  const out = [];
  const re = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = re.exec(String(html || ''))) !== null) {
    if (m[1].indexOf('_INITIAL_STATE') !== -1 && m[1].indexOf('pagedSlot') !== -1) out.push(m[1]);
  }
  return out.join('\n');
}

// 서비스워커가 새로 뜨면(확장 리로드·브라우저 재시작) 이전 수집 루프는 이미 죽어 있다.
// running 플래그만 남아 "이미 수집이 진행 중입니다"로 영구히 막히는 것을 막는다.
(async () => {
  try {
    const s = await chrome.storage.local.get(['rfBulk']);
    if (s.rfBulk && s.rfBulk.running) {
      // 사용자가 계속 수집을 원하는 세션(desired)이면 running 을 내리지 않는다 — 화면이 "수집 종료"로
      // 깜빡이지 않게 하고, 곧바로 재개를 예약한다(SW 가 방금 떴으니 이전 루프는 확실히 죽어 있다).
      if (s.rfBulk.desired && !s.rfBulk.stop) {
        setTimeout(() => { resumeBulkIfNeeded('sw-restart', true); }, 0);
      } else {
        await chrome.storage.local.set({ rfBulk: Object.assign({}, s.rfBulk, { running: false, stop: false, current: '' }) });
      }
    }
  } catch (e) { /* noop */ }
})();

// ── 핸들러 확장 — background.js 의 handlers 객체에 사내 전용 핸들러를 덧붙인다 ──────────
Object.assign(handlers, {
  /**
   * 쇼핑 노출 키워드 — 기본은 실제 쇼핑 탭 문서 읽기. 옵션으로 모바일 HTML 요청.
   * 요청 403은 같은 키워드 탭에서 1회 재확인한 최종 결과만 차단 정책에 전달한다.
   * 탭 상품은 기존 서버가 파싱하는 _INITIAL_STATE 형식으로 변환한다.
   */
  async resumeShopSerp({ collectorIp }) {
    return shopSerpPolicy.resume(collectorIp || 'browser');
  },
  async shopSerpStatus() { return globalThis.rfSerpCurrent || {}; },
  async fetchShopSerp({ keyword, target, analysisId, collectorIp, interval_ms, interval_revision, collection_mode, parallel_tabs = 1, tab_open_interval_ms = 3000 }, sender) {
    // 탭(관리자 분석 화면)에서 온 호출이면 백그라운드 순위확인 큐가 양보한다 — 같은 IP 이중 크롤 방지
    if (sender && sender.tab) lastScreenSerpAt = Date.now();
    const kw = String(keyword || '').trim();
    if (!kw) return { ok: false, message: '키워드가 비었습니다.' };
    if (!(sender && sender.tab)) {
      const settings = await getStore();
      const policy = await apiFetch('/api/ext/shop-keyword/interval-policy', { token: settings.token, apiBase: settings.apiBase });
      if (!policy.ok || !policy.json?.data) return { ok: false, message: '간격 정책을 읽지 못했습니다.' };
      ({ collector_ip: collectorIp, interval_ms, interval_revision, collection_mode, parallel_tabs, tab_open_interval_ms } = policy.json.data);
    }
    const result = await shopSerpPool.run(analysisId, kw, parallel_tabs, async ({tab, policy}) => {
    tab.openIntervalMs = tab_open_interval_ms;
    return policy.run(kw, async effectiveGap => {
      globalThis.rfSerpCurrent = { analysisId, keyword: kw, screen: '통합검색' };
      if (collection_mode !== 'fetch') return tab.read(kw, target);
      const read = async (url, source) => {
        if (tab.allowOpen && !tab.allowOpen()) return {ok:false,deferred:true};
        const r = await handlers.spFetchHtml({url});
        const captcha = /보안문자|자동\s*입력\s*방지|비정상적인\s*(검색|접근)|접근이\s*제한/.test(r.text || '');
        return {ok: r.ok && !captcha, status: r.status, captcha, html: source === 'shopping' && r.ok && !captcha ? ShopSerpTab.fetchedHtml(r.text || '') : r.text || '', result_source: source,
          message: captcha ? '보안문자 대기 — 브라우저 탭으로 열기로 바꿔 사람이 풀어 주세요.' : r.message};
      };
      const integrated = await read('https://m.search.naver.com/search.naver?where=m&query=' + encodeURIComponent(kw), 'integrated');
      if (!integrated.ok || /data-slog-container=["']shp_lis|data-shopping-block|네이버 쇼핑 인기상품/.test(integrated.html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ''))) return integrated;
      await sleep(Math.max(1000, Number(effectiveGap) || Number(interval_ms) || 4000));
      globalThis.rfSerpCurrent = { analysisId, keyword: kw, screen: '쇼핑' };
      return read('https://msearch.shopping.naver.com/search/all?query=' + encodeURIComponent(kw), 'shopping');
    }, collectorIp || 'browser', interval_ms, interval_revision, collection_mode === 'fetch' ? null : () => tab.peek(kw), (collection_mode || 'tab') + JSON.stringify(target || {}));
    }, tab_open_interval_ms);
    if (result.ok) {
      try { chrome.action.setBadgeText({ text: '' }); chrome.alarms.clear('rf-skw-check-retry'); } catch (e) { /* noop */ }
    }
    if (analysisId && !(sender && sender.tab) && (!result.cached || result.ok) && !result.cooldown) {
      const kind = result.captcha ? '보안문자' : [403, 429].includes(result.status) ? String(result.status) : result.ok ? 'success' : null;
      if (kind) {
        try {
          const { token, apiBase } = await getStore();
          const policy = (await chrome.storage.local.get('rfSerpPolicy')).rfSerpPolicy || {};
          await apiFetch('/api/ext/shop-keyword/' + Number(analysisId) + '/collector-event', {
            method: 'POST', token, apiBase,
            body: { kind, collector: 'browser', blocked_on_resume: kind !== 'success' && !!policy.blockedOnResume, interval_ms: result.interval_ms },
          });
        } catch (e) { /* reporting must not interrupt collection */ }
      }
    }
    return result;
  },

  /**
   * 코어 키워드 신호 수집(25 보충) — ① m.search 가격비교 HTML(경쟁 브랜드·속성·내 상품)
   * ② "함께 많이 찾는"(qra) JSON 을 **모바일 + PC 합집합**으로. 부분 실패는 빈 값으로 넘어간다.
   * qra 는 서버/curl 에선 503 — 실제 브라우저(확장) fetch 로만 안정적으로 받아진다(실측).
   */
  async fetchKeywordSignals({ keyword }) {
    const kw = String(keyword || '').trim();
    if (!kw) return { ok: false, message: '키워드가 비었습니다.' };
    const out = { ok: true, mshop_html: '', related: [] };
    const seen = {};
    const addRelated = (queries) => {
      for (const q of queries) {
        const k = String(q || '').trim();
        if (k && !seen[k]) { seen[k] = 1; out.related.push(k); }
      }
    };
    // SERP HTML 에 박힌 qra 모듈 API URL 을 뽑아 1회 호출 → "함께 많이 찾는" 키워드
    const qraFrom = async (html) => {
      const m = String(html || '').match(/https:\/\/s\.search\.naver\.com\/p\/qra\/[^"\\\s]*/);
      if (!m) return [];
      try {
        const rq = await fetch(m[0].replace(/&amp;/g, '&'), { credentials: 'include' });
        if (!rq.ok) return [];
        const j = await rq.json();
        return ((j && j.result && j.result.contents) || []).map((it) => String((it && it.query) || ''));
      } catch (e) { return []; }
    };
    try {
      const r = await fetch('https://m.search.naver.com/search.naver?where=m&query=' + encodeURIComponent(kw), {
        credentials: 'include',
        headers: { Accept: 'text/html,application/xhtml+xml' },
      });
      if (r.ok) {
        const html = await r.text();
        out.mshop_html = pickInitialStateScripts(html);
        addRelated(await qraFrom(html));   // 모바일 "함께 많이 찾는"
      }
    } catch (e) { /* 부분 실패 허용 */ }
    try {
      const r = await fetch('https://search.naver.com/search.naver?query=' + encodeURIComponent(kw), {
        credentials: 'include',
        headers: { Accept: 'text/html,application/xhtml+xml' },
      });
      if (r.ok) addRelated(await qraFrom(await r.text()));   // PC 합집합
    } catch (e) { /* 부분 실패 허용 */ }
    out.related = out.related.slice(0, 60);
    return out;
  },

  /**
   * 상품페이지를 백그라운드 탭으로 잠깐 열어 product.js 자동수집(saveProductInfo)을 기다린다(25).
   * 서버는 상품페이지가 429 라 직접 못 가져오고, 단순 fetch 는 스토어 SPA 라 파싱이 안 된다 —
   * 실제 페이지 로드 + 기존 수집 코드를 재사용하는 게 가장 정확하다.
   */
  async collectProductPage({ url }) {
    const m = String(url || '').match(/^https:\/\/(?:smartstore|brand)\.naver\.com\/[^/]+\/products\/(\d+)/i);
    if (!m) return { ok: false, message: '스마트스토어/브랜드 상품 URL이 아닙니다.' };
    const pid = m[1];
    if (productInfoWaiters.has(pid)) return { ok: false, message: '이미 수집 중입니다.' };

    let tab = null;
    try {
      tab = await chrome.tabs.create({ url: m[0], active: false });
    } catch (e) {
      return { ok: false, message: '탭 열기 실패: ' + String((e && e.message) || e) };
    }
    // 네이버 로그인·캡차 게이트 감지(2026-07-23) — 자동 열림 탭을 네이버가 nid/captcha 로 돌리면
    // 수집이 영영 안 끝난다. 탭을 앞으로 가져와 사용자가 직접 확인하게 하고, 그 탭은 닫지 않는다.
    let gate = false;
    const onUpd = (tabId, info) => {
      if (!tab || tabId !== tab.id || !info.url) return;
      if (/^https:\/\/(nid\.naver\.com|captcha\.naver\.com|ncpt\.naver\.com)\//i.test(info.url)) {
        gate = true;
        try { chrome.tabs.update(tab.id, { active: true }); } catch (e) { /* noop */ }
        const w = productInfoWaiters.get(pid);
        if (w) w({ ok: false, needLogin: true });
      }
    };
    try { chrome.tabs.onUpdated.addListener(onUpd); } catch (e) { /* noop */ }
    const result = await new Promise((resolve) => {
      const timer = setTimeout(() => resolve(null), 25000);
      productInfoWaiters.set(pid, (r) => { clearTimeout(timer); resolve(r); });
    });
    try { chrome.tabs.onUpdated.removeListener(onUpd); } catch (e) { /* noop */ }
    productInfoWaiters.delete(pid);

    if (gate) {
      // 로그인 확인 탭은 유지 — 사용자가 로그인(확인)한 뒤 다시 수집하면 정상 진행
      return { ok: false, product_id: pid, needLogin: true,
        message: '네이버가 로그인(보안) 확인을 요구했습니다 — 방금 열린 탭에서 확인·로그인한 뒤 "상품정보 다시 수집"을 다시 눌러주세요.' };
    }
    removeTab(tab && tab.id);

    if (!result) return { ok: false, product_id: pid, message: '상품정보 수집 시간 초과 — 상품 페이지를 한 번 직접 열어주세요.' };
    // 수집 payload 를 페이지에 직접 돌려준다 — 페이지가 자기 서버에 저장(확장 로그인·apiBase 무관)
    return { ok: !!(result.ok || result.payload), product_id: pid, info: result.payload || null, message: result.message || '' };
  },

  /** 통합검색 등 비쇼핑 페이지 위임 수집 — 쇼핑 검색 페이지를 백그라운드 탭으로 열어 상품을 수집해 회신. */
  /**
   * 대량 자동 수집 — 서버 대기열(미수집·오래된 키워드)을 받아 한 건씩 연속 수집한다.
   * 쇼핑 키워드가 수만 개라 사람이 하나씩 클릭할 수 없다. 진행 상황은 rfBulk 로 저장해 화면이 폴링한다.
   */
  async bulkShopStart({ limit, delayMs, concurrency, force }) {
    // ★ 이 SW 인스턴스에 살아있는 루프가 있으면 중복 시작하지 않는다(동기 선점 — 알람 워치독/재시작 훅이
    //   같은 순간 재개를 시도해도 두 루프가 뜨지 않게 한다). bulkLoopActive 는 첫 await 전에 세운다.
    if (bulkLoopActive) {
      return { ok: !!force, alreadyRunning: true, message: force ? '' : '이미 수집이 진행 중입니다. (중단하려면 중단 버튼)' };
    }
    bulkLoopActive = true;   // 선점 — 이후 어떤 조기 반환에서도, 루프 종료(finally)에서도 반드시 내린다.

    const { token, apiBase } = await getStore();
    if (!token) { bulkLoopActive = false; return { ok: false, loggedIn: false, message: '확장에 로그인해 주세요.' }; }

    // 워치독 재개(force)면 죽은 세션의 진행 수치를 이어받아 0 으로 리셋되지 않게 한다(서버 큐가 이어 수집).
    const prev = (await chrome.storage.local.get(['rfBulk'])).rfBulk || null;
    const resuming = !!(force && prev && prev.desired && !prev.stop);
    const seedDone = resuming ? (Number(prev.done) || 0) : 0;
    const seedFailed = resuming ? (Number(prev.failed) || 0) : 0;

    // limit=0(또는 미지정) = 무제한 — 카테고리를 순서대로 끝까지. 멈춰도 서버 대기열이 이어할 지점을 알려준다.
    const max = Number(limit) > 0 ? Math.min(100000, Number(limit)) : Infinity;
    // 너무 빨리 열면 네이버가 일시 차단한다 — 건당 최소 4초, 기본 6초.
    const baseGap = Math.max(1000, Number(delayMs) || 6000);   // 하한 1초 — 차단되면 아래에서 1초씩 자동으로 늘린다
    // 병렬 수집 — 동시에 탭 N개. 많을수록 빠르지만 차단 위험이 커진다(1~10).
    const conc = Math.min(10, Math.max(1, Number(concurrency) || 2));
    // ★ 콜드스타트 버스트 방지 — 처음부터 conc개(예: 10) 탭을 한꺼번에 열면 네이버가 바로 429/차단한다.
    //   낮게(warmStart) 시작해 성공이 이어지면 1씩 올리고(램프업), 차단되면 절반으로 줄인다.
    const warmStart = conc <= 2 ? conc : 2;
    await chrome.storage.local.set({ rfBulk: {
      running: true, done: seedDone, failed: seedFailed, total: (max === Infinity ? 0 : max), current: '', category: '',
      conc: warmStart, target: conc, gap: baseGap, blockedUntil: 0, startedAt: Date.now(), stop: false, lastError: '',
      heartbeat: Date.now(),   // 살아있음 표시 — 끊기면 죽은 세션으로 보고 워치독이 재개
      desired: true,           // 사용자가 계속 수집을 원함 — 워치독이 재개 판단에 쓴다(중단·완주 시 false)
      params: { limit: Number(limit) || 0, delayMs: baseGap, concurrency: conc },   // 워치독 재개용 원본 파라미터
    } });
    // ★ 워치독 알람 — SW 가 죽어도 이 알람이 SW 를 깨워 루프를 재개한다(desired 인 동안 30~60초 주기).
    try { chrome.alarms.create(BULK_WATCHDOG_ALARM, { periodInMinutes: 0.5, delayInMinutes: 0.5 }); } catch (e) { /* noop */ }

    // 백그라운드로 진행(응답은 즉시) — 화면은 bulkShopStatus 로 폴링
    (async () => {
      const MAX_GAP = 10000;    // 간격 상한 10초
      let done = seedDone, failed = seedFailed;   // 워치독 재개면 이전 진행 수치를 이어받는다
      let gap = baseGap;        // 차단이 뜨면 1초씩 늘리고, 성공이 이어지면 천천히 되돌린다
      let queue = [];           // 서버 대기열 버퍼
      let category = '';
      let stopped = false;
      let blocked = false;      // 차단 상태 — 모든 워커가 대기한다
      let liveConc = warmStart; // 실제 동시 수 — 낮게 시작(warmStart)해 성공하면 올리고 차단되면 줄인다
      let ceiling = conc;       // 동시 수 상한(sticky) — 429 뜬 수보다 낮춰 잡고 그 아래로만 램프업.
                                //   자꾸 상한까지 올라 재차단되는 진동(5→429→2→5→429…)을 끊어 지속 가능한 수에서 안정시킨다.
      let blockHits = 0;        // 연속 차단 횟수
      let okStreak = 0;         // 연속 성공 횟수 — 일정 이상이면 동시 수를 1 올린다(램프업)
      let cleanStreak = 0;      // 마지막 차단 이후 연속 성공 — 충분히 쌓이면 상한을 아주 천천히 한 단계만 복구(재탐색)
      let exhausted = false;    // 모든 분류 소진 — 대기 중이던 워커도 이걸 보고 종료한다
      const RAMP_EVERY = 4;     // 연속 성공 N회마다 동시 수 +1 (ceiling 까지 — 조금 천천히 올려 오버슛 줄임)

      const patch = async (o) => {
        const cur = (await chrome.storage.local.get(['rfBulk'])).rfBulk || {};
        await chrome.storage.local.set({ rfBulk: Object.assign({}, cur, o, { heartbeat: Date.now() }) });
      };
      const isStopped = async () => stopped || !!((await chrome.storage.local.get(['rfBulk'])).rfBulk || {}).stop;
      // 대기 중에도 중단이 즉시 먹히도록 잘게 쪼개 잔다(6~10초 sleep 중 중단 눌러도 바로 멈춤)
      const sleep = async (ms) => {
        const end = Date.now() + ms;
        while (Date.now() < end) {
          await new Promise((r) => setTimeout(r, Math.min(500, end - Date.now())));
          if (stopped || await isStopped()) { stopped = true; return; }
        }
      };
      // 살아있음 신호 — 루프가 죽으면 끊긴다(그때만 재시작 허용)
      const hb = setInterval(() => { patch({}); }, 15000);

      // 카테고리 순서(1차 → 2차 → 3차)로 대기열을 받는다. 비면 서버에서 다음 분류를 받아온다.
      // ★ 워커가 동시에 호출하면 각자 같은 20개를 받아 같은 키워드를 중복 수집한다(실측: 4개 워커가 '린넨원피스' 반복).
      //   → 리필을 단일 체인으로 직렬화하고, 이미 꺼낸 키워드는 taken 으로 걸러 한 번만 나가게 한다.
      const taken = new Set();
      let refill = Promise.resolve();
      // ★ 리필(대기열 재요청) 실패를 '소진'으로 오인하지 않는다.
      //   예전엔 apiFetch 가 네트워크 blip·일시 5xx 로 {ok:false} 를 주면 곧바로 종료돼,
      //   리필이 잦은 100~300개 지점에서 한 번만 삐끗해도 전체 수집이 '수집 종료'로 멈췄다(실측 증상).
      //   → 실패/일시 빈 큐는 재시도하고, 서버가 '더 없음(remaining=0)'을 명시할 때만 종료한다.
      let retryStreak = 0;              // 연속 재시도(실패·일시 빈 큐) 횟수 — 안전 상한까지만 버틴다
      const RETRY_MAX = 20;             // 이만큼 연속 재시도해도 못 채우면(≈수 분) 서버 이상으로 보고 종료
      const next = async () => {
        while (true) {
          while (queue.length) {
            const kw = queue.shift();
            if (kw && !taken.has(kw)) { taken.add(kw); return kw; }
          }
          // outcome: 'got'(큐 채움) · 'done'(서버가 소진 확인) · 'retry'(일시적 — 종료 금지)
          let outcome = 'retry';
          refill = refill.then(async () => {
            if (queue.length) { outcome = 'got'; return; }   // 다른 워커가 이미 채웠다
            // 동시 수가 많으면 20개는 금방 비어 리필이 잦아진다 — 동시 수에 맞춰 넉넉히 받는다(서버 상한 50)
            const qLimit = Math.min(50, Math.max(20, conc * 4));
            const { ok, json, status } = await apiFetch('/api/ext/keyword-shop-serp/queue?mode=category&limit=' + qLimit, { token, apiBase });
            if (!ok || !json || !json.data) {                // 네트워크·5xx·비정상 응답 — 종료하지 말고 재시도
              outcome = 'retry';
              await patch({ lastError: '대기열 조회 일시 실패(' + (status || 0) + ') — 재시도 중' });
              return;
            }
            const d = json.data;
            queue = (d.keywords || []).filter((k) => !taken.has(k));   // 서버가 또 준 것(수집 반영 전)은 제외
            if (d.category && d.category !== category) {
              category = d.category;
              await patch({ category, categoryIndex: d.category_index || 0, categoryTotal: d.category_total || 0, remaining: d.remaining || 0 });
            } else {
              await patch({ remaining: d.remaining || 0 });
            }
            if (queue.length) outcome = 'got';
            else if ((d.remaining || 0) > 0) outcome = 'retry';   // 남았지만 지금은 전부 리스(수집 중)/타워커가 가져감 — 잠시 뒤 다시
            else outcome = 'done';                                 // 서버가 명시적으로 '더 없음' 확인 → 진짜 종료
          }).catch(async () => { outcome = 'retry'; });            // 리필이 던져도 종료하지 않는다
          await refill;

          if (outcome === 'got') { retryStreak = 0; continue; }    // 큐 채워짐 → 위 while 에서 꺼낸다
          if (outcome === 'done') return null;                     // 진짜 소진 — 종료
          // 'retry' — 종료하지 말고 백오프 후 다시(중단 시 즉시 빠짐)
          if (++retryStreak >= RETRY_MAX) { await patch({ lastError: '대기열이 오래 비어 종료합니다.' }); return null; }
          await sleep(Math.min(15000, 2000 + retryStreak * 1000));
          if (stopped || await isStopped()) { stopped = true; return null; }
        }
      };

      // 차단 판정 — 네이버가 실제로 막았을 때의 문구만 본다.
      // '시간이 초과'는 차단이 아니라 우리 쪽이 오래 걸린 것이라 여기서 뺀다
      // (실측: 가격비교 많은 의류 키워드에서 카탈로그를 다 읽다 초과 → 창엔 차단 메시지가 없었다).
      const looksBlocked = (msg) => /차단|429|일시적으로 제한|데이터를 찾지 못|페이지가 열리지 않/.test(String(msg || ''));

      // 탭 여는 간격(stagger) — 예전엔 0.3초 고정이라, 동시 4~5개가 콜드스타트에 1초 남짓 안에 몰려 열려
      //   네이버가 429로 막았다(실측). → 매 오픈마다 현재 gap(차단 시 증가)·liveConc(차단 시 감소)로 간격을 계산해
      //   벌린다: 평상시 baseGap/conc(기본 6초/5≈1.2초), 차단이 뜨면 자동으로 더 벌어진다(예: gap 10초·동시 2 → 5초).
      //   최소 1초 보장. gap 통째로(6초) 직렬 대기시키면 동시성이 무의미하므로 동시수로 나눠 '몰림'만 막는다.
      let openChain = Promise.resolve();
      const openSlot = () => {
        const wait = Math.max(1000, Math.round(gap / Math.max(1, liveConc)));
        const my = openChain.then(() => sleep(wait));
        openChain = my;
        return my;
      };

      let workerNo = 0;
      const worker = async () => {
        const me = workerNo++;                              // 0..conc-1 — 워밍업/차단으로 정원이 바뀌면 합류·대기한다
        while (!stopped && !exhausted && done + failed < max) {
          // 아직/이미 정원(liveConc) 밖이면 — 종료하지 말고 대기한다.
          // 워밍업으로 정원이 늘면 합류하고, 차단으로 줄면 다시 빠진다(종료 X → 회복 시 재합류).
          if (me >= liveConc) {
            await sleep(1500);
            continue;                                       // 다시 조건 검사(stopped/exhausted/정원 반영)
          }
          if (await isStopped()) { stopped = true; break; }

          // 차단 중이면 다음 작업을 하지 않고 대기한다(계속 두드리면 더 오래 막힌다)
          while (blocked && !stopped) {
            await sleep(2000);
            if (await isStopped()) { stopped = true; break; }
          }
          if (stopped) break;

          const kw = await next();
          if (!kw) { exhausted = true; break; }             // 모든 분류를 다 비웠다 — 대기 중 워커도 종료시킨다

          await openSlot();                                 // ★ 탭 여는 순번 대기(직렬)
          if (stopped || blocked) continue;
          await patch({ current: kw });

          const r = await handlers.collectShopSerp({ keyword: kw, count: 80 });
          if (r && r.ok) {
            done++;
            gap = Math.max(baseGap, gap - 1000);            // 성공하면 1초씩 되돌린다(하한 = 설정값)
            blockHits = 0;                                  // 잘 돌고 있다 — 연속 차단 카운터 초기화
            // ★ 램프업 — 성공이 이어지면 동시 수를 ceiling(차단 학습된 상한)까지 1씩 천천히 올린다.
            //   (콜드스타트에 10개를 한꺼번에 열지 않고, 네이버가 받아주는 만큼만 서서히 늘린다)
            okStreak++;
            cleanStreak++;
            // 상한 복구 — 차단 없이 아주 오래(40회) 잘 돌면 상한을 1만 올려 재탐색(네이버가 잠잠해졌을 수 있다).
            //   보수적으로: 자꾸 상한까지 올라 재차단되는 걸 사용자가 싫어하므로 드물게만 위로 떠본다.
            if (cleanStreak >= 40 && ceiling < conc) { ceiling++; cleanStreak = 0; }
            // 성공했으면 직전 실패/차단 사유를 지운다 — 안 지우면 failed 누적 때문에
            // "차단 감지, N초 대기 후 재개" 가 수집이 잘 돼도 화면에 계속 남는다(실측)
            if (okStreak >= RAMP_EVERY && liveConc < ceiling) {
              liveConc++;
              okStreak = 0;
              await patch({ done, failed, gap, conc: liveConc, target: ceiling, blockedUntil: 0, lastError: '' });
            } else {
              await patch({ done, failed, gap, blockedUntil: 0, lastError: '' });
            }
          } else {
            failed++;
            const lastError = (r && r.message) || '알 수 없는 오류';
            if (looksBlocked(lastError)) {
              // 차단 — 간격을 1초 늘리고(최대 10초), 그 시간만큼 전 워커가 쉰다
              gap = Math.min(MAX_GAP, gap + 1000);
              blocked = true;
              blockHits++;
              okStreak = 0;                                 // 차단됨 — 램프업 진행도 초기화(다시 낮은 데서 올린다)
              cleanStreak = 0;

              // ★ 상한(ceiling)을 sticky 하게 낮춘다 — 방금 열려던 동시 수보다 낮게 잡아, 램프업이 다시 그 위로
              //   올라가 재차단되는 진동(5→429→2→5→429…)을 끊는다. 몇 번 부딪히면 지속 가능한 낮은 수에서 안정.
              ceiling = Math.max(2, Math.min(ceiling - 1, liveConc - 1));
              if (liveConc > ceiling) liveConc = ceiling;
              // 차단이 이어지면 더 빠르게(절반) 줄여 탈출한다(줄인 워커는 정원 밖이라 스스로 빠진다)
              if (blockHits >= 2 && liveConc > 2) {
                liveConc = Math.max(2, Math.floor(liveConc / 2));
                blockHits = 0;
              }

              // 차단이 반복될수록 더 오래 쉰다(429 는 계속 두드리면 더 길어진다)
              const rest = Math.min(60000, gap * (1 + blockHits));
              const until = Date.now() + rest;
              await patch({ done, failed, gap, conc: liveConc, target: ceiling,
                lastError: lastError + ' — 차단 감지, ' + Math.round(rest / 1000) + '초 대기 후 재개(동시 ' + liveConc + '/' + ceiling + ')',
                blockedUntil: until });
              await sleep(rest);
              blocked = false;
              // 대기 종료 — 차단 안내도 함께 지워 재개 후 낡은 사유가 남지 않게 한다
              await patch({ blockedUntil: 0, lastError: '' });
            } else {
              await patch({ done, failed, gap, lastError });
            }
          }
          // 다음 탭 간격은 openSlot 이 관리한다(여기서 또 쉬면 이중 대기)
        }
      };

      try {
        await Promise.all(Array.from({ length: conc }, () => worker()));
      } finally {
        clearInterval(hb);
        bulkLoopActive = false;
        // 정상 종료(소진·중단·완주)로 여기 왔다 — running·desired 를 내리고 워치독 알람을 해제한다.
        // (SW 가 죽어 루프가 끊긴 경우엔 finally 가 안 돌아 desired 가 남고, 알람이 재개한다.)
        await patch({ running: false, current: '', stop: false, desired: false, finishedAt: Date.now() });
        try { await chrome.alarms.clear(BULK_WATCHDOG_ALARM); } catch (e) { /* noop */ }
      }
    })();

    return { ok: true, started: true, total: (max === Infinity ? 0 : max), concurrency: conc };
  },

  /** 대량 수집 진행 상황 */
  async bulkShopStatus() {
    const s = await chrome.storage.local.get(['rfBulk']);
    return { ok: true, bulk: s.rfBulk || { running: false, done: 0, failed: 0, total: 0, current: '' } };
  },

  /** 대량 수집 중단 */
  async bulkShopStop() {
    const s = await chrome.storage.local.get(['rfBulk']);
    // desired 를 내려 워치독이 더는 재개하지 않게 하고, 알람도 정리한다(현재 키워드까지만 마치고 멈춤).
    if (s.rfBulk) await chrome.storage.local.set({ rfBulk: Object.assign({}, s.rfBulk, { stop: true, desired: false }) });
    try { await chrome.alarms.clear(BULK_WATCHDOG_ALARM); } catch (e) { /* noop */ }
    return { ok: true };
  },

  /**
   * 관리자 화면 요청 — 쇼핑 상품(상위 80)을 수집해 서버에 저장한다.
   * 서버는 search.shopping 이 418 이라 직접 수집할 수 없어 확장이 대신한다.
   */
  async collectShopSerp({ keyword, count }) {
    const kw = String(keyword || '').trim();
    if (!kw) return { ok: false, message: '키워드가 없습니다.' };

    const { token, apiBase } = await getStore();
    if (!token) return { ok: false, loggedIn: false, message: '확장에 로그인해 주세요.' };

    const col = await handlers.collectShopping({ keyword: kw, count: Number(count) || 80 });
    if (!col || !col.ok || !Array.isArray(col.products) || !col.products.length) {
      return { ok: false, message: (col && col.message) || '상품 수집에 실패했습니다.' };
    }

    const products = col.products.slice(0, Number(count) || 80).map((p, i) => ({
      title: String(p.title || ''),
      rank: p.rank || i + 1,
      price: Number(p.price) || 0,
      mallName: String(p.mallName || ''),
      link: String(p.link || ''),
      isAd: !!p.isAd,
      talkId: String(p.talkId || ''),   // 톡톡 코드(talk.naver.com/ct/{code}) — 관리자에서 톡톡 열기용
      storeId: String(p.storeId || ''), // 스토어 핸들(smartstore/brand) — 서버가 스마트스토어만 저장한다
      reviewCount: Number(p.reviewCount) || 0,
      isCatalog: !!p.isCatalog,         // 가격비교는 저장하지 않는다(서버에서도 한 번 더 막는다)
      // 시장분석 산출용(0.3.7) — 서버가 C1 산식으로 판매량·매출·시장분석 문서를 만든다
      purchase6m: Number(p.purchase6m) || 0,
      revenue6m: p.revenue6m != null && Number.isFinite(+p.revenue6m) ? Math.round(+p.revenue6m) : null,
      mallCount: Number(p.mallCount) || 0,
      sellerCount: Number(p.sellerCount) || 0,
      mallGrade: String(p.mallGrade || ''),
      category: String(p.category || ''),
    })).filter((p) => p.title);

    const { ok, json } = await apiFetch('/api/ext/keyword-shop-serp', {
      method: 'POST',
      body: { keyword: kw, total: col.total || 0, products, related_tags: col.relatedTags || [] },
      token,
      apiBase,
    });
    if (!ok) return { ok: false, message: (json && json.message) || '서버 저장에 실패했습니다.' };

    return { ok: true, saved: (json && json.data && json.data.saved) || products.length, total: col.total || 0 };
  },
});

// ── 알람·부트 훅 — 핸들러 등록 뒤에 와야 첫 알람이 빈 handlers 를 만나지 않는다 ─────────
try {
  chrome.alarms.onAlarm.addListener((a) => {
    if (a && a.name === 'rf-skw-watchdog') watchShopKeywordQueue();
    if (a && a.name === 'rf-skw-check-retry') drainShopKeywordCheckQueue();
    if (a && a.name === BULK_WATCHDOG_ALARM) resumeBulkIfNeeded('alarm');
    // 상품정보 → 순위확인 순서(각자 자기 플래그로 중복 방지)
    if (a && a.name === SKW_QUEUE_ALARM) drainShopKeywordProductQueue().then(drainShopKeywordCheckQueue);
    // 쇼핑 순위체크 워커 — 위 큐와 별도 알람(각자 자기 플래그로 중복 방지)
    if (a && a.name === SHOP_RANK_ALARM) drainShopRankQueue('알람');
  });
  chrome.alarms.get('rf-skw-watchdog').then(a => {
    if (!a) chrome.alarms.create('rf-skw-watchdog', { periodInMinutes: 1, delayInMinutes: 1 });
  }).catch(() => {});
  chrome.alarms.create(SKW_QUEUE_ALARM, { periodInMinutes: 3, delayInMinutes: 1 });
  // 순위체크는 사람이 결과를 기다리는 경우가 있어 더 자주 본다(MV3 알람 최소 주기는 1분).
  chrome.alarms.create(SHOP_RANK_ALARM, { periodInMinutes: 1, delayInMinutes: 0.5 });
} catch (e) { /* noop */ }

/*
 * 서비스워커가 뜨자마자 한 번 — 알람(첫 30초)만 기다리면 확장을 갓 재로드했을 때 반응이 없어
 * "동작하는지 안 하는지" 알 수가 없다. 브라우저 시작·확장 재로드·워커 부활 모두 여기로 들어온다.
 */
try {
  chrome.runtime.onStartup.addListener(() => { drainShopRankQueue('브라우저시작'); });
  chrome.runtime.onInstalled.addListener(() => { drainShopRankQueue('설치/갱신'); });
} catch (e) { /* noop */ }
// 이 배너가 콘솔에 안 보이면 **로드된 확장이 구버전**이다(chrome://extensions 에서 새로고침 필요).
try {
  console.log('[RankFree] background ' + (chrome.runtime.getManifest().version) + ' 로드 — 순위워커 활성');
} catch (e) { /* noop */ }
setTimeout(() => { try { drainShopRankQueue('워커기동'); } catch (e) { /* noop */ } }, 1500);
